package hashCode2015;

import java.util.List;

public class GlobalData {
	public int nbRows;
	public int rowSize;
	public int nbUnavaible;
	public int nbGroup;
	public int nbServer;
	public List<Row> listRows;
	List<Server> listServers;
}
