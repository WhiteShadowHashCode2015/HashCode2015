package hashCode2015;

public class FreeBlock {

	public int idxStart;
	public int size;
	
	public FreeBlock(int idxStart, int size) {
		super();
		this.idxStart = idxStart;
		this.size = size;
	}
	
	
	
}
